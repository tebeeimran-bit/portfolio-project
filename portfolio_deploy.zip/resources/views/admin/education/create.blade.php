@extends('admin.layouts.app')

@section('title', 'Add Education')

@section('content')
<div class="page-header">
    <h1>Add Education</h1>
    <p>Add new academic background or certification.</p>
</div>

<div class="form-card">
    <form action="{{ route('admin.education.store') }}" method="POST">
        @csrf
        
        <div class="form-row">
            <div class="form-group">
                <label for="institution">Institution *</label>
                <input type="text" id="institution" name="institution" class="form-control" value="{{ old('institution') }}" required placeholder="e.g. University of Technology">
            </div>
            <div class="form-group">
                <label for="degree">Degree/Major *</label>
                <input type="text" id="degree" name="degree" class="form-control" value="{{ old('degree') }}" required placeholder="e.g. Bachelor of Computer Science">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="location">Location</label>
                <input type="text" id="location" name="location" class="form-control" value="{{ old('location') }}" placeholder="Jakarta, Indonesia">
            </div>
            <div class="form-group">
                <label for="is_current" style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="checkbox" id="is_current" name="is_current" value="1" {{ old('is_current') ? 'checked' : '' }} style="width: auto; cursor: pointer;">
                    <span>Sedang Berjalan (Currently Studying)</span>
                </label>
                <small class="form-text" style="color: var(--text-secondary); margin-top: 4px;">Centang jika pendidikan masih berlangsung</small>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="start_date">Start Date *</label>
                <input type="date" id="start_date" name="start_date" class="form-control" value="{{ old('start_date') }}" required>
            </div>
            <div class="form-group">
                <label for="end_date">End Date</label>
                <input type="date" id="end_date" name="end_date" class="form-control" value="{{ old('end_date') }}" placeholder="Leave blank if currently studying">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="gpa">GPA</label>
                <input type="text" id="gpa" name="gpa" class="form-control" value="{{ old('gpa') }}" placeholder="e.g. 3.8">
            </div>
            <div class="form-group">
                <label for="order">Sort Order</label>
                <input type="number" id="order" name="order" class="form-control" value="{{ old('order', 0) }}" min="0">
            </div>
        </div>

        <div class="form-group">
            <label for="description">Description (Optional)</label>
            <textarea id="description" name="description" class="form-control" rows="4" placeholder="Brief description of your studies, thesis, or achievements...">{{ old('description') }}</textarea>
        </div>

        <div class="form-actions">
            <a href="{{ route('admin.education.index') }}" class="btn btn-outline">Cancel</a>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Save Education
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const isCurrentCheckbox = document.getElementById('is_current');
    const endDateInput = document.getElementById('end_date');
    
    function toggleEndDate() {
        if (isCurrentCheckbox.checked) {
            endDateInput.value = '';
            endDateInput.disabled = true;
            endDateInput.style.opacity = '0.5';
            endDateInput.style.cursor = 'not-allowed';
        } else {
            endDateInput.disabled = false;
            endDateInput.style.opacity = '1';
            endDateInput.style.cursor = 'text';
        }
    }
    
    isCurrentCheckbox.addEventListener('change', toggleEndDate);
    toggleEndDate(); // Initial state
});
</script>
@endsection
