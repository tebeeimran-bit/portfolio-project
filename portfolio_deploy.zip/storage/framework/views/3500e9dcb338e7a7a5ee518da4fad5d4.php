

<?php $__env->startSection('title', 'Kelola Proyek'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div>
            <h1>Manajemen Proyek</h1>
            <p>Kelola, edit, dan pantau semua proyek portofolio Anda.</p>
        </div>
        <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Tambah Proyek Baru
        </a>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class="fas fa-folder"></i>
        </div>
        <div class="stat-content">
            <h3>Total Proyek</h3>
            <div class="stat-value"><?php echo e($projects->total()); ?></div>
            <div class="stat-change"><i class="fas fa-arrow-up"></i> +2 bulan ini</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">
            <i class="fas fa-globe"></i>
        </div>
        <div class="stat-content">
            <h3>Publik</h3>
            <div class="stat-value"><?php echo e(\App\Models\Project::where('status', 'published')->count()); ?></div>
            <div style="height: 6px; background: var(--bg-card); border-radius: 3px; margin-top: 8px;">
                <div style="height: 100%; width: 80%; background: var(--accent-green); border-radius: 3px;"></div>
            </div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange">
            <i class="fas fa-file-alt"></i>
        </div>
        <div class="stat-content">
            <h3>Draf</h3>
            <div class="stat-value"><?php echo e(\App\Models\Project::where('status', 'draft')->count()); ?></div>
            <a href="#" style="font-size: 12px; background: var(--accent-orange); color: var(--bg-primary); padding: 4px 10px; border-radius: 4px; margin-top: 8px; display: inline-block;">Butuh Review</a>
        </div>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <form action="<?php echo e(route('admin.projects.index')); ?>" method="GET" style="flex: 1; display: flex; gap: 12px;">
        <div class="topbar-search" style="flex: 1; max-width: 400px;">
            <i class="fas fa-search"></i>
            <input type="text" name="search" placeholder="Cari berdasarkan judul, klien, atau tag..." value="<?php echo e(request('search')); ?>">
        </div>
        <select name="category" class="form-control" style="width: 180px;" onchange="this.form.submit()">
            <option value="all">Semua Kategori</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                    <?php echo e($category->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="sort" class="form-control" style="width: 140px;" onchange="this.form.submit()">
            <option value="created_at" <?php echo e(request('sort') == 'created_at' ? 'selected' : ''); ?>>Terbaru</option>
            <option value="title" <?php echo e(request('sort') == 'title' ? 'selected' : ''); ?>>Nama</option>
        </select>
    </form>
</div>

<!-- Projects Table -->
<div class="data-table">
    <table>
        <thead>
            <tr>
                <th>Cover</th>
                <th>Project Info</th>
                <th>Category</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="table-thumbnail">
                            <?php if($project->thumbnail): ?>
                                <img src="<?php echo e(asset('storage/' . $project->thumbnail)); ?>" alt="<?php echo e($project->title); ?>">
                            <?php else: ?>
                                <div class="table-thumbnail-placeholder">
                                    <i class="fas fa-image"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <div class="table-title"><?php echo e($project->title); ?></div>
                        <div class="table-subtitle">Client: <?php echo e($project->client ?? '-'); ?></div>
                    </td>
                    <td>
                        <span class="category-badge"><?php echo e($project->category->name ?? 'Uncategorized'); ?></span>
                    </td>
                    <td><?php echo e($project->created_at->format('M d, Y')); ?></td>
                    <td>
                        <span class="status-badge <?php echo e($project->status); ?>">
                            <?php echo e($project->status == 'published' ? 'Publik' : 'Draf'); ?>

                        </span>
                    </td>
                    <td>
                        <div class="table-actions">
                            <a href="<?php echo e(route('projects.show', $project->slug)); ?>" class="action-btn" title="View" target="_blank">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                            <a href="<?php echo e(route('admin.projects.edit', $project)); ?>" class="action-btn" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.projects.destroy', $project)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Yakin ingin menghapus proyek ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="action-btn danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                        <i class="fas fa-folder-open" style="font-size: 32px; margin-bottom: 12px; display: block; opacity: 0.5;"></i>
                        Tidak ada proyek ditemukan.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <?php if($projects->hasPages()): ?>
        <div class="table-footer">
            <div class="table-info">
                Menampilkan <?php echo e($projects->firstItem()); ?> sampai <?php echo e($projects->lastItem()); ?> dari <?php echo e($projects->total()); ?> proyek
            </div>
            <div class="table-pagination">
                <?php if($projects->onFirstPage()): ?>
                    <span class="page-btn" style="opacity: 0.5;">Sebelumnya</span>
                <?php else: ?>
                    <a href="<?php echo e($projects->previousPageUrl()); ?>" class="page-btn">Sebelumnya</a>
                <?php endif; ?>
                
                <?php $__currentLoopData = $projects->getUrlRange(1, $projects->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($url); ?>" class="page-btn <?php echo e($projects->currentPage() == $page ? 'active' : ''); ?>"><?php echo e($page); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php if($projects->hasMorePages()): ?>
                    <a href="<?php echo e($projects->nextPageUrl()); ?>" class="page-btn">Selanjutnya</a>
                <?php else: ?>
                    <span class="page-btn" style="opacity: 0.5;">Selanjutnya</span>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/admin/projects/index.blade.php ENDPATH**/ ?>