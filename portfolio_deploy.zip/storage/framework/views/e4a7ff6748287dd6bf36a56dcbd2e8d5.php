

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div>
            <h1>Daftar Proyek</h1>
            <p>Kelola konten portofolio Anda</p>
        </div>
        <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Tambah Proyek
        </a>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class="fas fa-folder"></i>
        </div>
        <div class="stat-content">
            <h3>Total Proyek</h3>
            <div class="stat-value"><?php echo e($totalProjects); ?></div>
            <div class="stat-change">
                <i class="fas fa-arrow-up"></i> +2 bulan ini
            </div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <h3>Publikasi</h3>
            <div class="stat-value"><?php echo e($publishedProjects); ?></div>
            <div class="stat-change">Aktif di portofolio</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange">
            <i class="fas fa-edit"></i>
        </div>
        <div class="stat-content">
            <h3>Draft</h3>
            <div class="stat-value"><?php echo e($draftProjects); ?></div>
            <div class="stat-change">Belum dipublikasi</div>
        </div>
    </div>
</div>

<!-- Recent Projects Table -->
<div class="data-table">
    <table>
        <thead>
            <tr>
                <th>Thumbnail</th>
                <th>Judul Proyek</th>
                <th>Kategori</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $recentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="table-thumbnail">
                            <?php if($project->thumbnail): ?>
                                <img src="<?php echo e(asset('storage/' . $project->thumbnail)); ?>" alt="<?php echo e($project->title); ?>">
                            <?php else: ?>
                                <div class="table-thumbnail-placeholder">
                                    <i class="fas fa-image"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <div class="table-title"><?php echo e($project->title); ?></div>
                        <div class="table-subtitle"><?php echo e($project->client ?? 'Personal Project'); ?></div>
                    </td>
                    <td>
                        <span class="category-badge"><?php echo e($project->category->name ?? 'Uncategorized'); ?></span>
                    </td>
                    <td><?php echo e($project->created_at->format('d M Y')); ?></td>
                    <td>
                        <span class="status-badge <?php echo e($project->status); ?>">
                            <?php echo e($project->status == 'published' ? 'Published' : 'Draft'); ?>

                        </span>
                    </td>
                    <td>
                        <div class="table-actions">
                            <a href="<?php echo e(route('admin.projects.edit', $project)); ?>" class="action-btn" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.projects.destroy', $project)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Yakin ingin menghapus proyek ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="action-btn danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                        <i class="fas fa-folder-open" style="font-size: 32px; margin-bottom: 12px; display: block; opacity: 0.5;"></i>
                        Belum ada proyek. <a href="<?php echo e(route('admin.projects.create')); ?>" style="color: var(--primary);">Tambah proyek pertama</a>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>