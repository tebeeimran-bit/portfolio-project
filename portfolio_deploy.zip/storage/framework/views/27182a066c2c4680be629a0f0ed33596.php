

<?php $__env->startSection('title', 'Kontak - Portfolio'); ?>

<?php $__env->startSection('content'); ?>
<!-- Contact Hero -->
<section class="contact-hero">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">📲 Contact</span>
            <h1 class="section-title" style="font-size: 48px; margin-bottom: 16px;">Find Me On.</h1>
            <p class="section-subtitle">Let's connect and build something amazing together!</p>
        </div>

        <!-- Social Links Grid -->
        <div class="social-grid">
            <?php $profile = \App\Models\Profile::first(); ?>
            
            <?php if($profile && isset($profile->social_links['github'])): ?>
                <a href="<?php echo e($profile->social_links['github']); ?>" target="_blank" class="social-card">
                    <div class="social-icon github">
                        <i class="fab fa-github"></i>
                    </div>
                    <div class="social-info">
                        <h3>Github</h3>
                        <p>Check out my repositories</p>
                    </div>
                </a>
            <?php else: ?>
                <a href="#" class="social-card">
                    <div class="social-icon github">
                        <i class="fab fa-github"></i>
                    </div>
                    <div class="social-info">
                        <h3>Github</h3>
                        <p>Check out my repositories</p>
                    </div>
                </a>
            <?php endif; ?>

            <?php if($profile && isset($profile->social_links['twitter'])): ?>
                <a href="<?php echo e($profile->social_links['twitter']); ?>" target="_blank" class="social-card">
                    <div class="social-icon twitter">
                        <i class="fab fa-twitter"></i>
                    </div>
                    <div class="social-info">
                        <h3>Twitter</h3>
                        <p>Follow me for updates</p>
                    </div>
                </a>
            <?php else: ?>
                <a href="#" class="social-card">
                    <div class="social-icon twitter">
                        <i class="fab fa-twitter"></i>
                    </div>
                    <div class="social-info">
                        <h3>Twitter</h3>
                        <p>Follow me for updates</p>
                    </div>
                </a>
            <?php endif; ?>

            <?php if($profile && isset($profile->social_links['instagram'])): ?>
                <a href="<?php echo e($profile->social_links['instagram']); ?>" target="_blank" class="social-card">
                    <div class="social-icon instagram">
                        <i class="fab fa-instagram"></i>
                    </div>
                    <div class="social-info">
                        <h3>Instagram</h3>
                        <p>See my daily life</p>
                    </div>
                </a>
            <?php else: ?>
                <a href="#" class="social-card">
                    <div class="social-icon instagram">
                        <i class="fab fa-instagram"></i>
                    </div>
                    <div class="social-info">
                        <h3>Instagram</h3>
                        <p>See my daily life</p>
                    </div>
                </a>
            <?php endif; ?>

            <?php if($profile && isset($profile->social_links['linkedin'])): ?>
                <a href="<?php echo e($profile->social_links['linkedin']); ?>" target="_blank" class="social-card">
                    <div class="social-icon linkedin">
                        <i class="fab fa-linkedin-in"></i>
                    </div>
                    <div class="social-info">
                        <h3>LinkedIn</h3>
                        <p>Connect professionally</p>
                    </div>
                </a>
            <?php else: ?>
                <a href="#" class="social-card">
                    <div class="social-icon linkedin">
                        <i class="fab fa-linkedin-in"></i>
                    </div>
                    <div class="social-info">
                        <h3>LinkedIn</h3>
                        <p>Connect professionally</p>
                    </div>
                </a>
            <?php endif; ?>

            <a href="mailto:<?php echo e($profile->email ?? 'hello@portfolio.com'); ?>" class="social-card">
                <div class="social-icon gmail">
                    <i class="fas fa-envelope"></i>
                </div>
                <div class="social-info">
                    <h3>Gmail</h3>
                    <p><?php echo e($profile->email ?? 'hello@portfolio.com'); ?></p>
                </div>
            </a>

            <a href="https://wa.me/<?php echo e($profile->whatsapp ?? '6281234567890'); ?>" target="_blank" class="social-card">
                <div class="social-icon whatsapp">
                    <i class="fab fa-whatsapp"></i>
                </div>
                <div class="social-info">
                    <h3>WhatsApp</h3>
                    <p>Chat with me</p>
                </div>
            </a>

            <a href="#" class="social-card">
                <div class="social-icon discord">
                    <i class="fab fa-discord"></i>
                </div>
                <div class="social-info">
                    <h3>Discord</h3>
                    <p>Join my server</p>
                </div>
            </a>

            <a href="#" class="social-card">
                <div class="social-icon telegram">
                    <i class="fab fa-telegram-plane"></i>
                </div>
                <div class="social-info">
                    <h3>Telegram</h3>
                    <p>Message me directly</p>
                </div>
            </a>
        </div>
    </div>
</section>

<!-- Contact Form Section -->
<section class="section">
    <div class="container">
        <div class="section-header" style="text-align: center;">
            <span class="section-tag">✉️ Send Message</span>
            <h2 class="section-title">Or Drop Me a Message</h2>
        </div>

        <div style="max-width: 600px; margin: 0 auto;">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="contact-form-landing">
                <form action="<?php echo e(route('contact.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">Your Name</label>
                            <input type="text" id="name" name="name" class="form-control" placeholder="John Doe" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Your Email</label>
                            <input type="email" id="email" name="email" class="form-control" placeholder="john@example.com" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" class="form-control" placeholder="Project Inquiry">
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" class="form-control" rows="5" placeholder="Tell me about your project..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg" style="width: 100%; justify-content: center;">
                        <i class="fas fa-paper-plane"></i> Send Message
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/contact.blade.php ENDPATH**/ ?>