

<?php $__env->startSection('title', 'Tentang Saya - Portfolio'); ?>

<?php $__env->startSection('content'); ?>
<!-- About Hero -->
<section class="about-hero">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">😎 About Me</span>
            <h1 class="section-title" style="font-size: 48px; margin-bottom: 24px;">it's More About Me.</h1>
        </div>

        <div class="about-intro">
            <div class="about-photo">
                <?php if($profile && $profile->photo): ?>
                    <img src="<?php echo e(asset('storage/' . $profile->photo)); ?>" alt="<?php echo e($profile->name); ?>">
                <?php else: ?>
                    <div style="width: 100%; height: 100%; background: var(--bg-card); border-radius: 20px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-user" style="font-size: 60px; color: var(--text-muted);"></i>
                    </div>
                <?php endif; ?>
            </div>
            <div class="about-bio">
                <p style="font-size: 18px; color: var(--text-secondary); line-height: 1.8; margin-bottom: 24px;">
                    <?php echo e($profile->bio ?? 'I am an undergraduate student majoring in Informatics Engineering. I possess a strong understanding of programming languages and web development, along with hands-on experience in software development projects.'); ?>

                </p>
                <p style="font-size: 16px; color: var(--text-secondary); line-height: 1.8;">
                    <?php echo e($profile->story ?? 'I have hands-on experience with ReactJS and NextJS for the frontend, and using ExpressJS, Laravel for backend development. I\'m also experienced in mobile development with React Native and Kotlin.'); ?>

                </p>
            </div>
        </div>
    </div>
</section>

<!-- Experience Section -->
<section class="experience-section">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">💼 Experience</span>
            <h2 class="section-title">My Experience</h2>
        </div>

        <div class="experience-grid">
            <?php $__empty_1 = true; $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="experience-card">
                    <div class="experience-header">
                        <div>
                            <h3 class="experience-title"><?php echo e($experience->title); ?></h3>
                            <p class="experience-company"><?php echo e($experience->company); ?></p>
                        </div>
                        <span class="experience-date">
                            <?php echo e($experience->start_date->format('M Y')); ?> - <?php echo e($experience->end_date ? $experience->end_date->format('M Y') : 'Present'); ?>

                        </span>
                    </div>
                    <p class="experience-description"><?php echo e($experience->description); ?></p>
                    <?php if($experience->technologies): ?>
                        <div class="experience-tags">
                            <?php $__currentLoopData = $experience->technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="experience-tag"><?php echo e($tech); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p style="color: var(--text-secondary); text-align: center; padding: 40px;">No experiences added yet.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Skills Section -->
<section class="section">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">📊 Skills</span>
            <h2 class="section-title">Technical Proficiency</h2>
        </div>

        <div class="skills-card" style="max-width: 600px;">
            <div class="skill-bars">
                <?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="skill-item">
                        <div class="skill-header">
                            <span class="skill-name"><?php echo e($skill->name); ?></span>
                            <span class="skill-percent"><?php echo e($skill->percentage); ?>%</span>
                        </div>
                        <div class="skill-bar">
                            <div class="skill-progress" data-width="<?php echo e($skill->percentage); ?>"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p style="color: var(--text-secondary);">No skills added yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Tech Stack Section -->
<section class="tech-section">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">🎯 Technology</span>
            <h2 class="section-title">Tech Stack That I Use</h2>
        </div>

        <div class="tech-grid">
            <div class="tech-item">
                <i class="fab fa-js-square"></i>
                <span>JavaScript</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-php"></i>
                <span>PHP</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-python"></i>
                <span>Python</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-react"></i>
                <span>React</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-vuejs"></i>
                <span>Vue.js</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-laravel"></i>
                <span>Laravel</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-node-js"></i>
                <span>Node.js</span>
            </div>
            <div class="tech-item">
                <i class="fas fa-wind"></i>
                <span>Tailwind</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-docker"></i>
                <span>Docker</span>
            </div>
            <div class="tech-item">
                <i class="fas fa-database"></i>
                <span>MySQL</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-figma"></i>
                <span>Figma</span>
            </div>
            <div class="tech-item">
                <i class="fab fa-git-alt"></i>
                <span>Git</span>
            </div>
        </div>
    </div>
</section>

<!-- Hobbies Section -->
<?php if($profile && $profile->hobbies): ?>
    <section class="section">
        <div class="container">
            <div class="section-header">
                <span class="section-tag">🎮 Hobbies</span>
                <h2 class="section-title">When I'm Not Coding</h2>
            </div>

            <div style="display: flex; flex-wrap: wrap; gap: 16px;">
                <?php $__currentLoopData = $profile->hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tech-item">
                        <i class="fas fa-<?php echo e($hobby['icon'] ?? 'star'); ?>"></i>
                        <span><?php echo e($hobby['name']); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<!-- CTA Section -->
<section class="section" style="text-align: center;">
    <div class="container">
        <h2 class="section-title" style="margin-bottom: 16px;">Let's Work Together</h2>
        <p style="color: var(--text-secondary); margin-bottom: 32px; max-width: 500px; margin-left: auto; margin-right: auto;">
            Have a project in mind? I'd love to hear about it. Let's build something amazing.
        </p>
        <div style="display: flex; gap: 16px; justify-content: center;">
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary">
                <i class="fas fa-envelope"></i> Contact Me
            </a>
            <?php if($profile && $profile->cv_file): ?>
                <a href="<?php echo e(asset('storage/' . $profile->cv_file)); ?>" class="btn btn-outline" target="_blank">
                    <i class="fas fa-download"></i> Download CV
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Animate skill bars on load
    window.addEventListener('load', () => {
        setTimeout(() => {
            document.querySelectorAll('.skill-progress').forEach(bar => {
                const width = bar.getAttribute('data-width');
                bar.style.width = width + '%';
            });
        }, 300);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/about.blade.php ENDPATH**/ ?>