

<?php $__env->startSection('title', 'Projects - Portfolio'); ?>

<?php $__env->startSection('content'); ?>
<!-- Projects Hero -->
<section class="projects-hero">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">⚒️ Projects</span>
            <h1 class="section-title" style="font-size: 48px; margin-bottom: 16px;">it's My Projects.</h1>
        </div>

        <!-- Filter Tabs -->
        <div class="filter-tabs">
            <a href="<?php echo e(route('projects.index')); ?>" class="filter-tab <?php echo e(!request('category') ? 'active' : ''); ?>">All</a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('projects.index', ['category' => $category->id])); ?>" 
                   class="filter-tab <?php echo e(request('category') == $category->id ? 'active' : ''); ?>">
                    <?php echo e($category->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Projects Grid -->
<section class="section">
    <div class="container">
        <!-- Search Box -->
        <div style="max-width: 400px; margin-bottom: 40px;">
            <form action="<?php echo e(route('projects.index')); ?>" method="GET" style="display: flex; gap: 12px;">
                <input type="text" name="search" class="form-control" placeholder="Search projects..." value="<?php echo e(request('search')); ?>" style="flex: 1;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>

        <div class="projects-grid">
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('projects.show', $project->slug)); ?>" class="project-card">
                    <div class="project-thumbnail">
                        <?php if($project->thumbnail): ?>
                            <img src="<?php echo e(asset('storage/' . $project->thumbnail)); ?>" alt="<?php echo e($project->title); ?>">
                        <?php else: ?>
                            <div class="project-thumbnail-placeholder">
                                <i class="fas fa-image"></i>
                            </div>
                        <?php endif; ?>
                        <div class="project-overlay">
                            <span class="view-project">View Project <i class="fas fa-arrow-right"></i></span>
                        </div>
                        <div class="project-tags">
                            <?php if($project->tags): ?>
                                <?php $__currentLoopData = array_slice($project->tags, 0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="project-tag"><?php echo e($tag); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="project-info">
                        <h3><?php echo e($project->title); ?></h3>
                        <p><?php echo e(Str::limit($project->description, 100)); ?></p>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 60px; color: var(--text-secondary);">
                    <i class="fas fa-folder-open" style="font-size: 48px; margin-bottom: 16px; opacity: 0.3;"></i>
                    <p>No projects found. Add some from the admin panel!</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if($projects->hasPages()): ?>
            <div class="pagination">
                <?php echo e($projects->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/projects/index.blade.php ENDPATH**/ ?>