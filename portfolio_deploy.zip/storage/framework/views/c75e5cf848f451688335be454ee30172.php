

<?php $__env->startSection('title', 'Pesan'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Pesan Masuk</h1>
    <p>Kelola pesan dari pengunjung website</p>
</div>

<div class="message-list">
    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="message-item <?php echo e($message->is_read ? '' : 'unread'); ?>">
            <div class="message-avatar">
                <?php echo e(strtoupper(substr($message->name, 0, 1))); ?>

            </div>
            <div class="message-content">
                <div class="message-header">
                    <div>
                        <div class="message-sender"><?php echo e($message->name); ?></div>
                        <div class="message-email"><?php echo e($message->email); ?></div>
                    </div>
                    <div class="message-date"><?php echo e($message->created_at->diffForHumans()); ?></div>
                </div>
                <div class="message-subject"><?php echo e($message->subject ?? 'No Subject'); ?></div>
                <div class="message-preview"><?php echo e($message->message); ?></div>
            </div>
            <div class="message-actions">
                <a href="<?php echo e(route('admin.messages.show', $message)); ?>" class="action-btn" title="View">
                    <i class="fas fa-eye"></i>
                </a>
                <?php if (! ($message->is_read)): ?>
                    <form action="<?php echo e(route('admin.messages.read', $message)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="action-btn" title="Mark as Read">
                            <i class="fas fa-check"></i>
                        </button>
                    </form>
                <?php endif; ?>
                <form action="<?php echo e(route('admin.messages.destroy', $message)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Hapus pesan ini?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="action-btn danger" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div style="text-align: center; padding: 60px; color: var(--text-secondary); background: var(--bg-secondary); border-radius: 16px; border: 1px solid var(--border-color);">
            <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 16px; opacity: 0.3;"></i>
            <p>Belum ada pesan masuk.</p>
        </div>
    <?php endif; ?>
</div>

<?php if($messages->hasPages()): ?>
    <div style="display: flex; justify-content: center; margin-top: 24px;">
        <?php echo e($messages->links()); ?>

    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>