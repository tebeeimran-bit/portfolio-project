

<?php $__env->startSection('title', 'Manage Education'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div>
            <h1>Education</h1>
            <p>Manage your academic background and certifications.</p>
        </div>
        <a href="<?php echo e(route('admin.education.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Education
        </a>
    </div>
</div>

<div class="data-table">
    <table>
        <thead>
            <tr>
                <th>Institution</th>
                <th>Degree</th>
                <th>Period</th>
                <th>GPA</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="table-title"><?php echo e($education->institution); ?></div>
                    </td>
                    <td>
                        <div class="table-subtitle"><?php echo e($education->degree); ?></div>
                    </td>
                    <td>
                        <?php echo e($education->start_date->format('Y')); ?> - <?php echo e($education->end_date ? $education->end_date->format('Y') : 'Present'); ?>

                    </td>
                    <td>
                        <?php echo e($education->gpa ?? '-'); ?>

                    </td>
                    <td>
                        <div class="table-actions">
                            <a href="<?php echo e(route('admin.education.edit', $education)); ?>" class="action-btn" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.education.destroy', $education)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="action-btn danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                        <i class="fas fa-graduation-cap" style="font-size: 32px; margin-bottom: 12px; display: block; opacity: 0.5;"></i>
                        No education records found.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/admin/education/index.blade.php ENDPATH**/ ?>