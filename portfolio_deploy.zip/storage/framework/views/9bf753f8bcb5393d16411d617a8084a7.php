

<?php $__env->startSection('title', 'Edit Education'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Edit Education</h1>
    <p>Update academic background details.</p>
</div>

<div class="form-card">
    <form action="<?php echo e(route('admin.education.update', $education)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="form-row">
            <div class="form-group">
                <label for="institution">Institution *</label>
                <input type="text" id="institution" name="institution" class="form-control" value="<?php echo e(old('institution', $education->institution)); ?>" required>
            </div>
            <div class="form-group">
                <label for="degree">Degree/Major *</label>
                <input type="text" id="degree" name="degree" class="form-control" value="<?php echo e(old('degree', $education->degree)); ?>" required>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="location">Location</label>
                <input type="text" id="location" name="location" class="form-control" value="<?php echo e(old('location', $education->location)); ?>" placeholder="Jakarta, Indonesia">
            </div>
            <div class="form-group">
                <label for="is_current" style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="checkbox" id="is_current" name="is_current" value="1" <?php echo e(old('is_current', $education->is_current) ? 'checked' : ''); ?> style="width: auto; cursor: pointer;">
                    <span>Sedang Berjalan (Currently Studying)</span>
                </label>
                <small class="form-text" style="color: var(--text-secondary); margin-top: 4px;">Centang jika pendidikan masih berlangsung</small>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="start_date">Start Date *</label>
                <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo e(old('start_date', $education->start_date->format('Y-m-d'))); ?>" required>
            </div>
            <div class="form-group">
                <label for="end_date">End Date</label>
                <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo e(old('end_date', optional($education->end_date)->format('Y-m-d'))); ?>">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="gpa">GPA</label>
                <input type="text" id="gpa" name="gpa" class="form-control" value="<?php echo e(old('gpa', $education->gpa)); ?>">
            </div>
            <div class="form-group">
                <label for="order">Sort Order</label>
                <input type="number" id="order" name="order" class="form-control" value="<?php echo e(old('order', $education->order)); ?>" min="0">
            </div>
        </div>

        <div class="form-group">
            <label for="description">Description (Optional)</label>
            <textarea id="description" name="description" class="form-control" rows="4"><?php echo e(old('description', $education->description)); ?></textarea>
        </div>

        <div class="form-actions">
            <a href="<?php echo e(route('admin.education.index')); ?>" class="btn btn-outline">Cancel</a>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Update Education
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const isCurrentCheckbox = document.getElementById('is_current');
    const endDateInput = document.getElementById('end_date');
    
    function toggleEndDate() {
        if (isCurrentCheckbox.checked) {
            endDateInput.value = '';
            endDateInput.disabled = true;
            endDateInput.style.opacity = '0.5';
            endDateInput.style.cursor = 'not-allowed';
        } else {
            endDateInput.disabled = false;
            endDateInput.style.opacity = '1';
            endDateInput.style.cursor = 'text';
        }
    }
    
    isCurrentCheckbox.addEventListener('change', toggleEndDate);
    toggleEndDate(); // Initial state
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/admin/education/edit.blade.php ENDPATH**/ ?>