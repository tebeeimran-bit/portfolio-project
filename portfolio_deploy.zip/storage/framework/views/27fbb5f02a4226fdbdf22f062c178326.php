

<?php $__env->startSection('title', $project->title . ' - Portfolio'); ?>

<?php $__env->startSection('content'); ?>
<!-- Project Hero -->
<section class="project-hero">
    <div class="container">
        <span class="featured-badge">Featured Case Study</span>
        <h1 class="project-hero-title">
            <?php echo e($project->title); ?>

            <?php if($project->client): ?>
                <br><span class="highlight">for <?php echo e($project->client); ?></span>
            <?php endif; ?>
        </h1>
        <p class="project-hero-desc"><?php echo e($project->description); ?></p>
        
        <div class="project-hero-buttons">
            <?php if($project->live_url): ?>
                <a href="<?php echo e($project->live_url); ?>" target="_blank" class="btn btn-primary">
                    <i class="fas fa-external-link-alt"></i> Visit Live Site
                </a>
            <?php endif; ?>
            <?php if($project->code_url): ?>
                <a href="<?php echo e($project->code_url); ?>" target="_blank" class="btn btn-outline">
                    <i class="fas fa-code"></i> View Code
                </a>
            <?php endif; ?>
        </div>

        <div class="project-meta">
            <div class="meta-item">
                <div class="meta-label">Client</div>
                <div class="meta-value"><?php echo e($project->client ?? 'Personal'); ?></div>
            </div>
            <div class="meta-item">
                <div class="meta-label">Role</div>
                <div class="meta-value"><?php echo e($project->role ?? 'Developer'); ?></div>
            </div>
            <div class="meta-item">
                <div class="meta-label">Timeline</div>
                <div class="meta-value"><?php echo e($project->timeline ?? 'Ongoing'); ?></div>
            </div>
            <div class="meta-item">
                <div class="meta-label">Tools</div>
                <div class="meta-value">
                    <?php if($project->tools): ?>
                        <?php echo e(implode(', ', array_slice($project->tools, 0, 3))); ?>

                    <?php else: ?>
                        Various
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Project Content -->
<section class="project-content">
    <div class="container">
        <?php if($project->challenge): ?>
            <div class="content-section">
                <h2>The Challenge</h2>
                <div class="challenge-content">
                    <?php
                        $challenge = $project->challenge;
                        // Split by numbered pattern (1. 2. 3. etc)
                        $points = preg_split('/\d+\.\s/', $challenge, -1, PREG_SPLIT_NO_EMPTY);
                        $hasNumberedPoints = count($points) > 1;
                    ?>
                    
                    <?php if($hasNumberedPoints): ?>
                        <ul class="challenge-list">
                            <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(trim($point)): ?>
                                    <li><?php echo e(trim($point)); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p><?php echo e($challenge); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Project Gallery -->
        <!-- Project Gallery Carousel -->
        <div class="project-gallery-carousel">
            <div class="carousel-container">
                <div class="carousel-track">
                    <!-- Thumbnail (Main Image) -->
                    <?php if($project->thumbnail): ?>
                        <div class="carousel-slide">
                            <img src="<?php echo e(asset('storage/' . $project->thumbnail)); ?>" alt="<?php echo e($project->title); ?> - Main">
                        </div>
                    <?php endif; ?>

                    <!-- Additional Images -->
                    <?php if($project->images && is_array($project->images)): ?>
                        <?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-slide">
                                <img src="<?php echo e(asset('storage/' . $image)); ?>" alt="<?php echo e($project->title); ?> - Image <?php echo e($loop->iteration); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>

                <button class="carousel-btn prev-btn" aria-label="Previous image">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="carousel-btn next-btn" aria-label="Next image">
                    <i class="fas fa-chevron-right"></i>
                </button>

                <div class="carousel-indicators">
                    <!-- Indicators will be generated by JS -->
                </div>
            </div>
        </div>

        <?php if($project->solution): ?>
            <div class="content-section">
                <h2>The Solution & Results</h2>
                <div class="solution-content">
                    <?php
                        $solution = $project->solution;
                        // Split by numbered pattern (1. 2. 3. etc)
                        $points = preg_split('/\d+\.\s/', $solution, -1, PREG_SPLIT_NO_EMPTY);
                        $hasNumberedPoints = count($points) > 1;
                    ?>
                    
                    <?php if($hasNumberedPoints): ?>
                        <ul class="solution-list">
                            <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(trim($point)): ?>
                                    <li><?php echo e(trim($point)); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p><?php echo e($solution); ?></p>
                    <?php endif; ?>
                </div>

                <?php if($project->key_improvements): ?>
                    <h3 style="margin-top: 32px; margin-bottom: 16px;">Key Improvements</h3>
                    <div class="improvements-grid">
                        <?php $__currentLoopData = $project->key_improvements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $improvement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="improvement-card">
                                <div class="improvement-icon">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                                <div>
                                    <div class="improvement-value"><?php echo e($improvement['label'] ?? ''); ?></div>
                                    <div class="improvement-label"><?php echo e($improvement['description'] ?? ''); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const track = document.querySelector('.carousel-track');
        const slides = Array.from(track.children);
        const nextButton = document.querySelector('.next-btn');
        const prevButton = document.querySelector('.prev-btn');
        const indicatorsContainer = document.querySelector('.carousel-indicators');
        
        // Return if no slides
        if (slides.length === 0) return;

        // Create indicators
        slides.forEach((_, index) => {
            const indicator = document.createElement('div');
            indicator.classList.add('indicator');
            if (index === 0) indicator.classList.add('active');
            indicator.addEventListener('click', () => {
                moveToSlide(index);
            });
            indicatorsContainer.appendChild(indicator);
        });

        const indicators = Array.from(document.querySelectorAll('.indicator'));
        let currentIndex = 0;

        function updateButtons() {
            // Optional: Hide buttons at ends, but infinite loop is better or just keep them
            // For now, let's just keep them always active for loop or stop at ends
            // Loop implementation:
            /*
            if (currentIndex === 0) {
                prevButton.style.opacity = '0.5';
                prevButton.style.cursor = 'not-allowed';
            } else {
                prevButton.style.opacity = '1';
                prevButton.style.cursor = 'pointer';
            }
            */
        }

        function moveToSlide(index) {
            // Handle bounds for loop
            if (index < 0) index = slides.length - 1;
            if (index >= slides.length) index = 0;

            const amountToMove = -100 * index;
            track.style.transform = `translateX(${amountToMove}%)`;
            
            currentIndex = index;

            // Update indicators
            indicators.forEach(ind => ind.classList.remove('active'));
            if (indicators[currentIndex]) {
                indicators[currentIndex].classList.add('active');
            }
        }

        nextButton.addEventListener('click', () => {
            moveToSlide(currentIndex + 1);
        });

        prevButton.addEventListener('click', () => {
            moveToSlide(currentIndex - 1);
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') moveToSlide(currentIndex - 1);
            if (e.key === 'ArrowRight') moveToSlide(currentIndex + 1);
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/projects/show.blade.php ENDPATH**/ ?>