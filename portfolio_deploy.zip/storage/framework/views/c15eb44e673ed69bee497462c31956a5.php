

<?php $__env->startSection('title', 'Edit Proyek'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div>
            <h1>Edit Proyek</h1>
            <p>Perbarui detail proyek <?php echo e($project->title); ?></p>
        </div>
        <a href="<?php echo e(route('admin.projects.index')); ?>" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<form action="<?php echo e(route('admin.projects.update', $project)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    
    <div class="form-card">
        <div class="form-section">
            <h3>Informasi Dasar</h3>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="title">Judul Proyek *</label>
                    <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title', $project->title)); ?>" required>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="form-help" style="color: var(--accent-red);"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="category_id">Kategori *</label>
                    <select id="category_id" name="category_id" class="form-control" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id', $project->category_id) == $category->id ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="client">Nama Klien</label>
                    <input type="text" id="client" name="client" class="form-control" value="<?php echo e(old('client', $project->client)); ?>">
                </div>
                <div class="form-group">
                    <label for="role">Role / Posisi</label>
                    <input type="text" id="role" name="role" class="form-control" value="<?php echo e(old('role', $project->role)); ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="timeline">Timeline</label>
                    <input type="text" id="timeline" name="timeline" class="form-control" value="<?php echo e(old('timeline', $project->timeline)); ?>">
                </div>
                <div class="form-group">
                    <label for="status">Status *</label>
                    <select id="status" name="status" class="form-control" required>
                        <option value="draft" <?php echo e(old('status', $project->status) == 'draft' ? 'selected' : ''); ?>>Draft</option>
                        <option value="published" <?php echo e(old('status', $project->status) == 'published' ? 'selected' : ''); ?>>Published</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="description">Deskripsi Singkat</label>
                <textarea id="description" name="description" class="form-control" rows="3"><?php echo e(old('description', $project->description)); ?></textarea>
            </div>
        </div>

        <div class="form-section">
            <h3>Case Study</h3>
            
            <div class="form-group">
                <label for="challenge">The Challenge</label>
                <textarea id="challenge" name="challenge" class="form-control" rows="4"><?php echo e(old('challenge', $project->challenge)); ?></textarea>
            </div>

            <div class="form-group">
                <label for="solution">The Solution</label>
                <textarea id="solution" name="solution" class="form-control" rows="4"><?php echo e(old('solution', $project->solution)); ?></textarea>
            </div>
        </div>

        <div class="form-section">
            <h3>Media & Links</h3>
            
            <?php if($project->thumbnail): ?>
                <div class="form-group">
                    <label>Thumbnail Saat Ini</label>
                    <div style="margin-top: 8px;">
                        <img src="<?php echo e(asset('storage/' . $project->thumbnail)); ?>" alt="Current thumbnail" style="max-width: 200px; border-radius: 8px;">
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="form-group">
                <label for="thumbnail"><?php echo e($project->thumbnail ? 'Ganti Thumbnail' : 'Thumbnail Image'); ?></label>
                <label class="file-upload">
                    <input type="file" id="thumbnail" name="thumbnail" accept="image/*">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <p>Klik untuk upload gambar baru (Max 2MB)</p>
                </label>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="live_url">Live URL</label>
                    <input type="url" id="live_url" name="live_url" class="form-control" value="<?php echo e(old('live_url', $project->live_url)); ?>">
                </div>
                <div class="form-group">
                    <label for="code_url">Code Repository URL</label>
                    <input type="url" id="code_url" name="code_url" class="form-control" value="<?php echo e(old('code_url', $project->code_url)); ?>">
                </div>
            </div>
        </div>

        <div class="form-section">
            <h3>Tags & Tools</h3>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="tags">Tags</label>
                    <input type="text" id="tags" name="tags" class="form-control" value="<?php echo e(old('tags', is_array($project->tags) ? implode(', ', $project->tags) : $project->tags)); ?>">
                    <div class="form-help">Pisahkan dengan koma</div>
                </div>
                <div class="form-group">
                    <label for="tools">Tools / Technologies</label>
                    <input type="text" id="tools" name="tools" class="form-control" value="<?php echo e(old('tools', is_array($project->tools) ? implode(', ', $project->tools) : $project->tools)); ?>">
                    <div class="form-help">Pisahkan dengan koma</div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-check">
                    <input type="checkbox" name="featured" value="1" <?php echo e(old('featured', $project->featured) ? 'checked' : ''); ?>>
                    <span>Tampilkan di halaman utama (Featured)</span>
                </label>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Simpan Perubahan
            </button>
            <a href="<?php echo e(route('admin.projects.index')); ?>" class="btn btn-outline">Batal</a>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/admin/projects/edit.blade.php ENDPATH**/ ?>