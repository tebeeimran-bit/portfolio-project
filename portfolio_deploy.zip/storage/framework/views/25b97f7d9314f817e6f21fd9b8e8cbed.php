

<?php $__env->startSection('title', 'Manage Technologies'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div class="page-header-row">
        <div>
            <h1>Tech Stack</h1>
            <p>Manage technologies displayed on your portfolio.</p>
        </div>
        <a href="<?php echo e(route('admin.technologies.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Technology
        </a>
    </div>
</div>

<div class="data-table">
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Icon</th>
                <th>Order</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="table-title"><?php echo e($technology->name); ?></div>
                    </td>
                    <td>
                        <i class="<?php echo e($technology->icon); ?>" style="font-size: 24px; color: var(--primary);"></i>
                        <small style="display: block; color: var(--text-secondary); margin-top: 4px;"><?php echo e($technology->icon); ?></small>
                    </td>
                    <td>
                        <?php echo e($technology->order); ?>

                    </td>
                    <td>
                        <?php if($technology->is_active): ?>
                            <span class="badge badge-success">Active</span>
                        <?php else: ?>
                            <span class="badge badge-secondary">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="table-actions">
                            <a href="<?php echo e(route('admin.technologies.edit', $technology)); ?>" class="action-btn" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.technologies.destroy', $technology)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this technology?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="action-btn danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                        <i class="fas fa-code" style="font-size: 32px; margin-bottom: 12px; display: block; opacity: 0.5;"></i>
                        No technologies found. Add your first technology.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\.gemini\antigravity\scratch\portfolio\resources\views/admin/technologies/index.blade.php ENDPATH**/ ?>